This project is already packaged as a ZIP by ChatGPT.
Just download the ZIP, extract it, then follow LOCAL_SETUP_GUIDE.txt.
